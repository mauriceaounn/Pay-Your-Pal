package com.karimhammoud.payyourpal;

class GetAllBillsForMemberAsyncParams {

    String gName;
    int mid;

    GetAllBillsForMemberAsyncParams(String gName, int mid) {
        this.gName = gName;
        this.mid = mid;
    }
}
